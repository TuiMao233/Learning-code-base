/* Vue方法的集合函数 */
export default {
}
