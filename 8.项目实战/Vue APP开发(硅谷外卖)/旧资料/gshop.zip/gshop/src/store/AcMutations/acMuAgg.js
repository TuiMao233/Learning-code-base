import acMuAggFun from './acMuAggFun.js'
import addAcMu from '../acMutions.js'
let {addMethod, addAggregate} = acMuAggFun
export default {
  addAcMu,
  addMethod,
  addAggregate
}
