module.exports = {
  foo() {console.log('moudle2 foo()')}
}