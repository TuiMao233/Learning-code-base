module.exports = {
  foo() {console.log('moudle3 foo()')}
}
