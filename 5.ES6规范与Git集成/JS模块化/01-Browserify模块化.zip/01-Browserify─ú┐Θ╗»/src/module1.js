module.exports = {
	foo() {console.log('moudle1 foo()')}
}