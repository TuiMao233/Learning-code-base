define(function(){
	let data = 'dataService'
	getName = () =>{return data}
	return {getName}
})